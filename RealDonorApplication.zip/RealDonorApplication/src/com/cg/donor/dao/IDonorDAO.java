package com.cg.donor.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.donor.bean.DonorBean;
import com.cg.donor.exception.DonorException;

public interface IDonorDAO {
	public String addDonorDetails(DonorBean donor) throws DonorException, ClassNotFoundException, IOException, SQLException;
	public DonorBean viewDonorDetails(String donorId) throws DonorException, ClassNotFoundException, IOException, SQLException;
	public List<DonorBean> retriveAllDetails()throws DonorException, ClassNotFoundException, IOException, SQLException;

}

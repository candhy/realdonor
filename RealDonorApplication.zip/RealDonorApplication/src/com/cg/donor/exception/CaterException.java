package com.cg.donor.exception;

public class CaterException extends Exception{
	
	                 public CaterException(String message)
	                 {
		               super(message);
	                 }

}
